import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

export default function Header() {
  const { isAuthenticated, user } = useSelector((state) => state.auth);

  return (
    <header className="bg-sky-400 text-white shadow-md p-4 flex justify-between items-center">
      <Link to="/" className="text-xl font-bold">
        FitCoaches
      </Link>

      <nav className="flex gap-4 items-center">
        <Link to="/">Inicio</Link>
        <Link to="/buscar">Buscar servicios</Link>

        {!isAuthenticated ? (
          <>
            <Link to="/login" className="bg-white text-sky-500 px-4 py-1 rounded-full font-medium">Iniciar sesión</Link>
            <Link to="/register" className="bg-white text-sky-500 px-4 py-1 rounded-full font-medium">Registrar</Link>
          </>
        ) : user?.role === "cliente" ? (
          <>
            <Link to="/mis-servicios">Mis Contrataciones</Link>
            <Link to="/perfil">Mi Perfil</Link>
          </>
        ) : user?.role === "entrenador" ? (
          <>
            <Link to="/mis-servicios">Servicios</Link>
            <Link to="/estadisticas">Estadísticas</Link>
            <Link to="/perfil">Mi Perfil</Link>
          </>
        ) : null}
      </nav>
    </header>
  );
}
