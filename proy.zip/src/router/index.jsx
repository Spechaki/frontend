import { Routes, Route } from 'react-router-dom';
//import HomePage from '../pages/HomePage';
//import LoginPage from '../pages/LoginPage';
import RegisterConfirmPage from '../pages/RegisterConfirmPage';
import RegisterFormPage from '../pages/RegisterFormPage';

export default function AppRoutes() {
  return (
    <Routes>
      {/* <Route path="/" element={<HomePage />} /> */}
      {/* <Route path="/login" element={<LoginPage />} /> */}
      <Route path="/register" element={<RegisterConfirmPage />} />
      <Route path="/register/form" element={<RegisterFormPage />} />
    </Routes>
  );
}
