import axios from 'axios';

const BASE_URL = import.meta.env.VITE_API_KEY;

export const loginUser = async (credentials) => {
  const response = await axios.post(`${BASE_URL}/auth/login`, credentials);
  return response.data;
};
